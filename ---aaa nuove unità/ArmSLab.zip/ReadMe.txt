_____________                 /||\   
___   __  \_______________   / || \    ____ _
__   /_/  /  __/ _   _  _/__/ //\\ \___ __ _
_   __   // // / / / / /_____//  \\______ __ _
/__/ /__//_//_/ /_/ /_/ ____ \\  // ____ __ _
____________________________\ \\// /_____ __ _   
    -S U P E R L A B -       \ \/ /  __ _
        - by Xubor            \__/ _ _ 	
				   
Version       :            1.0 (15.08.03)
Energy Costs  :	        18000				
Metal  Costs  :		 8000				  
Build Time    :	        49000				
Armor	      :		 4500 HPs		        
Build Speed   :           250
Built by      :	          Adv. Constr. Kbot
Description   : This Lab produces lvl. 3 - units and serves as a counter to
		the Core Krogoth Gantry. 


the pictures were made by Stealth870 and Lord Phoenix

Note: Use the Conflict Crusher to move more units into it's build-menu.

This unit is available at  http://people.freenet.de/ringbrand
			   http://gamers-syndicate.com

Send Feedback to           Martin.Huedepohl@ePost.de

