
< ARM BANISHER SE advanced Gunship >

	by Warlord285 and Xubor

version:	  3.0 special edition 
energy costs: 16485	
metal costs:    537
buildtime:    31400
amor:           980 HPs
weapons:	    1: rapid laser, 75 HPs/sec (ID 252)
		    2: air2air laser, 15 HPs/sec

description:        less firepower than the Brawler, but
		    higher accuracy, higher speed and anti-
		    air-capacities



this unit can be downloaded at:

http://people.freenet.de/ringbrand


send feedback to:

Martin.Huedepohl@ePost.de	